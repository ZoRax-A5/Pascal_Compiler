Linux文件夹中放了Linux可执行程序
MacOS文件夹中放了MacOS可执行程序
运行示例
./Pascal_Compiler ../test/fibonacci.pas
./out